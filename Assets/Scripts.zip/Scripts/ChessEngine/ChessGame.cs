using SoftwareKingdom.Chess.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SoftwareKingdom.Chess.Core {

    public class MoveRecord{
        public Move appliedMove;
        public string takenPiece;
    }

    public class ChessGame
    {
        // Settings
        public string variantName;
        // Connections
        protected MoveGenerator moveGenerator;
        public Action<Move> OnMovePlayed;

        // State variables

        public BoardState boardState;
        public List<MoveRecord> moveRecords;

        public  ChessGame(BoardState initialState,MoveGenerator moveGenerator)
        {
            boardState = initialState;
            this.moveGenerator = moveGenerator;
            moveRecords = new List<MoveRecord>();
        }

     
        public virtual void PlayMove(Move move)
        {
            moveGenerator.ApplyMove(move,boardState);
            MoveRecord moveRecord = new MoveRecord();
            moveRecord.takenPiece = boardState[move.targetCoord];
            moveRecords.Add(moveRecord);
            OnMovePlayed?.Invoke(move);
        }

        public void UndoMove(Move move) // TODO: undo move from the list and stack, maybe generate a new boardState
        {

        }

        public virtual List<Move> GetPossibleMoves(Coord sourceCoord)
        {
            return moveGenerator.GeneratePieceMoves(boardState, sourceCoord);
        }
        


    }
}

