using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SoftwareKingdom.Chess.Core
{
    public class StandardChessGame : ChessGame
    {
        const int N_DIAGONAL_DIRECTIONS = 4;
        const int N_STRAIGHT_DIRECTIONS = 4;

        public static string[,] standardChessInitialBoard =
        {
            { "WR", "WN","WB", "WQ", "WK", "WB","WN","WR" },
            { "WP", "WP","WP","WP","WP","WP","WP" ,"WP" },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { "BP", "BP","BP","BP","BP","BP","BP" ,"BP" },
            { "BR", "BN","BB", "BQ", "BK", "BB","BN","BR" },
        };

        public static char[] pieceLetters = { 'P', 'N', 'B', 'R', 'Q', 'K' };


        static string[] initialFlags = { "WC0-0", "WC0-0-0", "BC0-0", "BC0-0-0" };

        // Settings

            // Connections

            // State variables
        public StandardChessGame(): base(CreateStandardInitialState(), CreateStandardMoveGenerator())
        {
            variantName = "Standard";
        }

        public static BoardState CreateStandardInitialState()
        {

            BoardState initialBoardState = new BoardState(standardChessInitialBoard, new List<string>(initialFlags));
            return initialBoardState;
        }

        public static MoveGenerator CreateStandardMoveGenerator()
        {

            MoveGenerator standardChessMoveGenerator = new MoveGenerator(
                pieceLetters,
                CreateStandardPieceMoveGenerators()
            );
            return standardChessMoveGenerator;
        } 

        public static IPieceMoveGenerator[] CreateStandardPieceMoveGenerators()
        {
            // Pawn
            PawnMoveGenerator pawnMoveGenerator = new PawnMoveGenerator();
            // Knight
            KnightMoveGenerator knightMoveGenerator = new KnightMoveGenerator();
            // Bishop
            Coord[] diagonalDirections = new Coord[N_DIAGONAL_DIRECTIONS];
            diagonalDirections[0] = new Coord(-1, 1);
            diagonalDirections[1] = new Coord(1, -1);
            diagonalDirections[2] = new Coord(1, 1);
            diagonalDirections[3] = new Coord(-1, -1);
            SlidingPieceMoveGenerator bishopMoveGenerator = new SlidingPieceMoveGenerator(diagonalDirections);

            // Rook
            Coord[] straightDirections = new Coord[N_STRAIGHT_DIRECTIONS];
            straightDirections[0] = new Coord(-1, 0);
            straightDirections[1] = new Coord(1, 0);
            straightDirections[2] = new Coord(0, -1);
            straightDirections[3] = new Coord(0, 1);
            SlidingPieceMoveGenerator rookMoveGenerator = new SlidingPieceMoveGenerator(straightDirections);

            // Queen
            Coord[] allDirections = new Coord[N_DIAGONAL_DIRECTIONS + N_STRAIGHT_DIRECTIONS];
            diagonalDirections.CopyTo(allDirections, 0);
            straightDirections.CopyTo(allDirections, diagonalDirections.Length);
            SlidingPieceMoveGenerator queenMoveGenerator = new SlidingPieceMoveGenerator(allDirections);
            // King
            KingMoveGenerator kingMoveGenerator = new KingMoveGenerator();

            return new IPieceMoveGenerator[] { pawnMoveGenerator, knightMoveGenerator, bishopMoveGenerator, rookMoveGenerator, queenMoveGenerator, kingMoveGenerator };

        }

    }
}

