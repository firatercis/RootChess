﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftwareKingdom.Chess.Core;
using SoftwareKingdom.Chess.SeedChess;
namespace SoftwareKingdom.Chess.UI {
	public class HumanPlayer : Player {

		public enum InputState {
			None,
			PieceSelected,
			DraggingPiece
		}

		InputState currentState;

		BoardUI boardUI;
		Camera cam;
		Coord selectedPieceSquare;
		Board board;
		public HumanPlayer (Board board) {
			boardUI = GameObject.FindObjectOfType<BoardUI> ();
			cam = Camera.main;
			this.board = board;
		}

		public override void NotifyTurnToMove () {

		}

		public override void Update () {
			//HandleInput ();
		}

		void HandleInput () {
			Vector2 mousePos = cam.ScreenToWorldPoint (Input.mousePosition);

			if (currentState == InputState.None) {
				HandlePieceSelection (mousePos);
			} else if (currentState == InputState.DraggingPiece) {
				HandleDragMovement (mousePos);
			} else if (currentState == InputState.PieceSelected) {
				HandlePointAndClickMovement (mousePos);
			}

			if (Input.GetMouseButtonDown (1)) {
				CancelPieceSelection ();
			}
		}

		void HandlePointAndClickMovement (Vector2 mousePos) {
			if (Input.GetMouseButton (0)) {
				HandlePiecePlacement (mousePos);
			}

			if (Input.GetMouseButton(1))
			{
                HandlePiecePlacement(mousePos,trySeed : true);
            }

		}

		void HandleDragMovement (Vector2 mousePos) {
			boardUI.DragPiece (selectedPieceSquare, mousePos);
			// If mouse is released, then try place the piece
			if (Input.GetMouseButtonUp (0)) {
				HandlePiecePlacement (mousePos);
			}


		}

		void HandlePiecePlacement (Vector2 mousePos, bool trySeed = false) {
			Coord targetSquare;
			if (boardUI.TryGetSquareUnderMouse (mousePos, out targetSquare)) {
				if (targetSquare.Equals (selectedPieceSquare)) {
					boardUI.ResetPiecePosition (selectedPieceSquare);
					if (currentState == InputState.DraggingPiece) { // TODO: 4 tane ic ice if.
						currentState = InputState.PieceSelected;
					} else {
						currentState = InputState.None;
						boardUI.DeselectSquare (selectedPieceSquare);
					}
				} else {
					Piece selectedPiece = board.GetPiece(targetSquare);
					if(selectedPiece != null && selectedPiece.colour == board.colourToMove)
					{
                        CancelPieceSelection();
                        HandlePieceSelection(mousePos);
					}
					else
					{
                        TryMakeMove(selectedPieceSquare, targetSquare, trySeed);
                    }
				}
			} else {
				CancelPieceSelection ();
			}

		}




        void CancelPieceSelection () {
			if (currentState != InputState.None) {
				currentState = InputState.None;
				boardUI.DeselectSquare (selectedPieceSquare);
				boardUI.ResetPiecePosition (selectedPieceSquare);
			}
		}

		void TryMakeMove (Coord startSquare, Coord targetSquare, bool isSeedMove = false) {

			bool moveIsLegal = false;
			

			//bool wantsKnightPromotion = Input.GetKey(KeyCode.LeftAlt);

			Piece piece = board.GetPiece(startSquare);

			var pseudoLegalMoves = piece.GenerateMoves(board); // TODO: Moves are generated twice
			if (pseudoLegalMoves.Count == 0)
			{
                CancelPieceSelection();
                return;
            }
				
            Move chosenMove = pseudoLegalMoves[0];

            for (int i = 0; i < pseudoLegalMoves.Count; i++)
			{
				var legalMove = pseudoLegalMoves[i];

				if (legalMove.targetCoord.Equals( targetSquare) && legalMove.IsSeedMove() == isSeedMove)
				{
					//if (legalMove.IsPromotion)
					//{
					//	if (legalMove.MoveFlag == Move.Flag.PromoteToQueen && wantsKnightPromotion)
					//	{
					//		continue;
					//	}
					//	if (legalMove.MoveFlag != Move.Flag.PromoteToQueen && !wantsKnightPromotion)
					//	{
					//		continue;
					//	}
					//}
					moveIsLegal = true;
					chosenMove = legalMove;
					//	Debug.Log (legalMove.PromotionPieceType);
					break;
				}
			}

			if (moveIsLegal)
			{
				ChoseMove(chosenMove);
				currentState = InputState.None;
			}
			else
			{
				CancelPieceSelection();
			}
		}

		void HandlePieceSelection (Vector2 mousePos) {
			if (Input.GetMouseButtonDown (0)) {
				if (boardUI.TryGetSquareUnderMouse (mousePos, out selectedPieceSquare)) {
					Piece selectedPiece = board.GetPiece(selectedPieceSquare);
					if(selectedPiece != null)
					{
						if(selectedPiece.colour == board.colourToMove)
						{
                            boardUI.HighlightLegalMoves(board, selectedPieceSquare);
                            boardUI.SelectSquare(selectedPieceSquare);
                            currentState = InputState.DraggingPiece;
                        }
					}
				}
			}
		}
	}
}