using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SoftwareKingdom.Chess.Core
{
    public class Bishop : SlidingPiece
    {
        public const int TYPE = 3;
        const int BISHOP_N_DIRECTIONS = 4;
        public Bishop(int colour)
        {
            this.colour = colour;
            this.type = TYPE;
            possibleDirections = new Coord[BISHOP_N_DIRECTIONS];
            possibleDirections[0] = new Coord(-1, 1);
            possibleDirections[1] = new Coord(1, -1);
            possibleDirections[2] = new Coord(1, 1);
            possibleDirections[3] = new Coord(-1, -1);

        }
    }
}

