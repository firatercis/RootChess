using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using SoftwareKingdom.Chess.Core;


namespace SoftwareKingdom.Chess.SeedChess
{
    public class Seed : Piece
    {
        public const int TYPE = 7;
        // Settings
        public Piece pieceGrown;
        public int levelToSprout;
        // Connections

        // State variables
        public int currentLevel;
        public bool isGrownFull;
        public override List<Move> GenerateMoves(Board board)
        {
            List<Move> moves = new List<Move>();
            return moves;
        }

        public Seed(Piece piece, int levelToSprout)
        {
            pieceGrown = piece;
            colour = piece.colour;
            this.levelToSprout = levelToSprout;
            type = TYPE;
            currentLevel = 0;
        }

        public int GetRemainingTurnTime()
        {
            return levelToSprout - currentLevel;
        }
        
        public void Grow()
        {
            currentLevel++;
            if(currentLevel == levelToSprout)
            {
                isGrownFull = true;
            }
        }

    }

}
