using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SoftwareKingdom.Chess.Core
{
    public class Rook : SlidingPiece
    {
        public const int TYPE = 4;
        const int ROOK_N_DIRECTIONS = 4;
        public Rook(int colour)
        {
            this.colour = colour;
            this.type = TYPE;
            possibleDirections = new Coord[ROOK_N_DIRECTIONS];
            possibleDirections[0] = new Coord(-1, 0);
            possibleDirections[1] = new Coord(1, 0);
            possibleDirections[2] = new Coord(0, -1);
            possibleDirections[3] = new Coord(0, 1);

        }
    }
}


