using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace SoftwareKingdom.Chess.Core
{
    public class Queen : SlidingPiece
    {
        public const int TYPE = 5;
        const int QUEEN_N_DIRECTIONS = 8;

        public Queen(int colour)
        {
            this.colour = colour;
            this.type = TYPE;
            possibleDirections = new Coord[QUEEN_N_DIRECTIONS];
            possibleDirections[0] = new Coord(-1, 0);
            possibleDirections[1] = new Coord(1, 0);
            possibleDirections[2] = new Coord(0, -1);
            possibleDirections[3] = new Coord(0, 1);
            possibleDirections[4] = new Coord(-1, 1);
            possibleDirections[5] = new Coord(1, -1);
            possibleDirections[6] = new Coord(1, 1);
            possibleDirections[7] = new Coord(-1, -1);

        }
    }
}
