using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SoftwareKingdom.Chess.Core
{
    public class Knight : Piece
    {
        public const int TYPE = 2;
        const int KNIGHT_N_DIRECTIONS = 8;
        private Coord[] possibleDirections = { };

        public Knight(int colour)
        {
            this.colour = colour;
            this.type = TYPE;
            possibleDirections = new Coord[KNIGHT_N_DIRECTIONS];
            possibleDirections[0] = new Coord(-2, 1);
            possibleDirections[1] = new Coord(2, 1);
            possibleDirections[2] = new Coord(-2, -1);
            possibleDirections[3] = new Coord(2, -1);
            possibleDirections[4] = new Coord(1, 2);
            possibleDirections[5] = new Coord(1, -2);
            possibleDirections[6] = new Coord(-1, 2);
            possibleDirections[7] = new Coord(-1, -2);
        }

        public override List<Move> GenerateMoves(Board board)
        {
            List<Move> moves = new List<Move>();
            //  ClearResultBuffer(resultBuffer);

            for (int i = 0; i < possibleDirections.Length; i++)
            {
                Coord direction = possibleDirections[i];
                Coord currentTargetPosition = position + direction;
          
                int currentColour = board.GetColor(currentTargetPosition);
                if (currentColour == Board.BLANK || currentColour == oppositeColour)
                {
                    Move move = new Move(position, currentTargetPosition);
                    moves.Add(move);
                }      
            }
            return moves;
        }
    }
}


