using System.Collections;
using System.Collections.Generic;

using UnityEngine;




namespace SoftwareKingdom.Chess.Core
{
    public class SlidingPiece : Piece
    {

        // Settings
        protected Coord[] possibleDirections = { };
        // Connections

        // State variables

        public override List<Move> GenerateMoves(Board board)
        {
            List<Move> moves = new List<Move>();
          //  ClearResultBuffer(resultBuffer);

            for (int i = 0; i < possibleDirections.Length; i++)
            {
                Coord direction = possibleDirections[i];
                Coord currentTargetPosition = position;
                while (true)
                {
                    currentTargetPosition += direction;

                    int currentColour = board.GetColor(currentTargetPosition);
                    if (currentColour == Board.BLANK || currentColour == oppositeColour)
                    {
                        Move move = new Move(position,currentTargetPosition);
                        moves.Add(move);
                    }
                    if (currentColour != Board.BLANK && !board.IsSeed(currentTargetPosition))
                        break;
                }
            }
            return moves;
        }



    }
}

 
