using SoftwareKingdom.Chess.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pawn : Piece
{
    public const int TYPE = 1;
    // Settings

    // Connections

    // State variables

    public Pawn(int colour)
    {
        this.colour = colour;
        this.type = TYPE;
    }

    public override List<Move> GenerateMoves(Board board)
    {
        List<Move> moves = new List<Move>();
        Coord moveDirection = colour==COLOR_WHITE ? new Coord(0,1) : new Coord(0,-1);
        int startRank = colour == COLOR_WHITE ? 1 : 6;
        int lastRank = colour == COLOR_WHITE ? 7 : 0;
        int finalRankBeforePromotion = colour == COLOR_WHITE ? 6 : 1;

        // one forward position
        Coord oneForward = position + moveDirection;
        if (board.GetColor(oneForward) == Board.BLANK)
        {
            Move oneForwardMove = new Move(position, oneForward);

            if (oneForward.rankIndex == lastRank)
                oneForwardMove.specialCondition = SpecialConditions.PromoteToQueen;

            moves.Add(oneForwardMove);
        }
        // two forward position
        Coord twoForward = oneForward + moveDirection;
        if (position.rankIndex == startRank && board.GetColor(twoForward) == Board.BLANK)
        {
            Move twoForwardMove = new Move(position, twoForward);
            twoForwardMove.specialCondition = SpecialConditions.PawnTwoForward;
            moves.Add(twoForwardMove);
        }

        // One point diagonals
        Coord leftDiagonal = oneForward + new Coord(1, 0);
        if(board.GetColor(leftDiagonal) == oppositeColour)
        {
            Move leftDiagonalTakeMove = new Move(position, leftDiagonal);
            moves.Add(leftDiagonalTakeMove);
        }
        Coord rightDiagonal = oneForward + new Coord(-1, 0);
        if (board.GetColor(rightDiagonal) == oppositeColour)
        {
            Move rightDiagonalTakeMove = new Move(position, rightDiagonal);
            moves.Add(rightDiagonalTakeMove);
        }

        // En passant?  TODO:


        return moves;
    }



    //void GeneratePawnMoves()
    //{
    //    PieceList myPawns = board.pawns[friendlyColourIndex];
    //    int pawnOffset = (friendlyColour == Piece.White) ? 8 : -8;
    //    int startRank = (board.WhiteToMove) ? 1 : 6;
    //    int finalRankBeforePromotion = (board.WhiteToMove) ? 6 : 1;

    //    int enPassantFile = ((int)(board.currentGameState >> 4) & 15) - 1;
    //    int enPassantSquare = -1;
    //    if (enPassantFile != -1)
    //    {
    //        enPassantSquare = 8 * ((board.WhiteToMove) ? 5 : 2) + enPassantFile;
    //    }

    //    for (int i = 0; i < myPawns.Count; i++)
    //    {
    //        int startSquare = myPawns[i];
    //        int rank = RankIndex(startSquare);
    //        bool oneStepFromPromotion = rank == finalRankBeforePromotion;

    //        if (genQuiets)
    //        {

    //            int squareOneForward = startSquare + pawnOffset;

    //            // Square ahead of pawn is empty: forward moves
    //            if (board.Square[squareOneForward] == Piece.None)
    //            {
    //                // Pawn not pinned, or is moving along line of pin
    //                if (!IsPinned(startSquare) || IsMovingAlongRay(pawnOffset, startSquare, friendlyKingSquare))
    //                {
    //                    // Not in check, or pawn is interposing checking piece
    //                    if (!inCheck || SquareIsInCheckRay(squareOneForward))
    //                    {
    //                        if (oneStepFromPromotion)
    //                        {
    //                            MakePromotionMoves(startSquare, squareOneForward);
    //                        }
    //                        else
    //                        {
    //                            moves.Add(new Move(startSquare, squareOneForward));
    //                        }
    //                    }

    //                    // Is on starting square (so can move two forward if not blocked)
    //                    if (rank == startRank)
    //                    {
    //                        int squareTwoForward = squareOneForward + pawnOffset;
    //                        if (board.Square[squareTwoForward] == Piece.None)
    //                        {
    //                            // Not in check, or pawn is interposing checking piece
    //                            if (!inCheck || SquareIsInCheckRay(squareTwoForward))
    //                            {
    //                                moves.Add(new Move(startSquare, squareTwoForward, Move.Flag.PawnTwoForward));
    //                            }
    //                        }
    //                    }
    //                }
    //            }
    //        }

    //        // Pawn captures.
    //        for (int j = 0; j < 2; j++)
    //        {
    //            // Check if square exists diagonal to pawn
    //            if (numSquaresToEdge[startSquare][pawnAttackDirections[friendlyColourIndex][j]] > 0)
    //            {
    //                // move in direction friendly pawns attack to get square from which enemy pawn would attack
    //                int pawnCaptureDir = directionOffsets[pawnAttackDirections[friendlyColourIndex][j]];
    //                int targetSquare = startSquare + pawnCaptureDir;
    //                int targetPiece = board.Square[targetSquare];

    //                // If piece is pinned, and the square it wants to move to is not on same line as the pin, then skip this direction
    //                if (IsPinned(startSquare) && !IsMovingAlongRay(pawnCaptureDir, friendlyKingSquare, startSquare))
    //                {
    //                    continue;
    //                }

    //                // Regular capture
    //                if (Piece.IsColour(targetPiece, opponentColour))
    //                {
    //                    // If in check, and piece is not capturing/interposing the checking piece, then skip to next square
    //                    if (inCheck && !SquareIsInCheckRay(targetSquare))
    //                    {
    //                        continue;
    //                    }
    //                    if (oneStepFromPromotion)
    //                    {
    //                        MakePromotionMoves(startSquare, targetSquare);
    //                    }
    //                    else
    //                    {
    //                        moves.Add(new Move(startSquare, targetSquare));
    //                    }
    //                }

    //                // Capture en-passant
    //                if (targetSquare == enPassantSquare)
    //                {
    //                    int epCapturedPawnSquare = targetSquare + ((board.WhiteToMove) ? -8 : 8);
    //                    if (!InCheckAfterEnPassant(startSquare, targetSquare, epCapturedPawnSquare))
    //                    {
    //                        moves.Add(new Move(startSquare, targetSquare, Move.Flag.EnPassantCapture));
    //                    }
    //                }
    //            }
    //        }
    //    }
    //}

    //void MakePromotionMoves(int fromSquare, int toSquare)
    //{
    //    moves.Add(new Move(fromSquare, toSquare, Move.Flag.PromoteToQueen));
    //    if (promotionsToGenerate == PromotionMode.All)
    //    {
    //        moves.Add(new Move(fromSquare, toSquare, Move.Flag.PromoteToKnight));
    //        moves.Add(new Move(fromSquare, toSquare, Move.Flag.PromoteToRook));
    //        moves.Add(new Move(fromSquare, toSquare, Move.Flag.PromoteToBishop));
    //    }
    //    else if (promotionsToGenerate == PromotionMode.QueenAndKnight)
    //    {
    //        moves.Add(new Move(fromSquare, toSquare, Move.Flag.PromoteToKnight));
    //    }

    //}
}
