using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace SoftwareKingdom.Chess.Core
{

    public abstract class Piece
    {
        public const int CAN_MOVE_TO = 1;
        public const int CANNOT_MOVE_TO = 0;

        public const int COLOR_WHITE = 0;
        public const int COLOR_BLACK = 1;
        public const int COLOR_NEUTRAL = 2;

        // Settings
        public int colour; // 0: white 1:black
        public int type; // Possible type of the piece
        public int level;

        public int oppositeColour
        {
            get { return 1 - colour; }
        }
        // Connections

        // State variables
        public Coord position;

        public abstract List<Move> GenerateMoves(Board board);

        

        public void ClearResultBuffer(int[,] resultBuffer)
        {
            // Clear the buffer
            for (int i = 0; i < resultBuffer.GetLength(0); i++)
            {
                for (int j = 0; j < resultBuffer.GetLength(1); j++)
                {
                    resultBuffer[i, j] = CANNOT_MOVE_TO;
                }
            }
        }
    }

}

