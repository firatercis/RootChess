using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using SoftwareKingdom.Chess.Core;


namespace SoftwareKingdom.Chess.Core
{
    public class King : Piece
    {
        const int KING_N_DIRECTIONS = 8;
        public const int TYPE = 6;
        // Settings
        Coord[] possibleDirections;
        // Connections

        // State variables

        public King(int colour)
        {
            this.colour = colour;
            this.type = TYPE;
            possibleDirections = new Coord[KING_N_DIRECTIONS];
            possibleDirections[0] = new Coord(-1, 0);
            possibleDirections[1] = new Coord(1, 0);
            possibleDirections[2] = new Coord(0, -1);
            possibleDirections[3] = new Coord(0, 1);
            possibleDirections[4] = new Coord(-1, 1);
            possibleDirections[5] = new Coord(1, -1);
            possibleDirections[6] = new Coord(1, 1);
            possibleDirections[7] = new Coord(-1, -1);

        }


        public override List<Move> GenerateMoves(Board board)
        {
            List<Move> moves = new List<Move>();
            for (int i = 0; i < possibleDirections.Length; i++)
            {
                Coord direction = possibleDirections[i];
                Coord currentTargetPosition = position + direction;

                int currentColour = board.GetColor(currentTargetPosition);
                if (currentColour == Board.BLANK || currentColour == oppositeColour)
                {
                    Move move = new Move(position, currentTargetPosition);
                    moves.Add(move);
                }

                if(currentColour == Board.BLANK) // Seed deployment move
                {
                    Move move = new Move(position, currentTargetPosition, SpecialConditions.DeploySeed);
                    moves.Add(move);
                }

            }
            return moves;
        }
    }

}

