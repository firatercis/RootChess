﻿


using System.Collections.Generic;

namespace SoftwareKingdom.Chess.Core
{
    public interface IMoveGenerator{
        List<Move> GenerateBoardMoves(BoardState boardState);
    }
}


