﻿namespace SoftwareKingdom.Chess.Core
{
    public interface IPieceMoveGenerator{
        Move[] GenerateMoves(BoardState boardState,Coord sourceCoord);
    }
}


