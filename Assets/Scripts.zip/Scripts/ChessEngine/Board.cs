using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

using SoftwareKingdom.Chess.SeedChess;

namespace SoftwareKingdom.Chess.Core
{
    public class Board
    {
        public const int BLANK = -1;
        public const int OCCUPIED = -2;
        // Settings

        // Connections
        public Piece whiteKing;
        public Piece blackKing;
        public event Action<int> OnKingLost;

        // State variables
        public Piece[,] piecePlacements;
        public Piece[,] piecePlacementsBuffered;

        public List<Seed> seeds;

        public int moveIndex;
        public int colourToMove;

        public Piece lastTakenPiece;
        public Move lastMadeMove;

        public Board(int nRanks, int nFiles)
        {
            piecePlacements = new Piece[nRanks, nFiles];
            piecePlacementsBuffered = new Piece[nRanks, nFiles];
            seeds = new List<Seed>();
        }

        public void SetTurn(int turn)
        {
            colourToMove = turn;
        }

        public Piece GetPiece(Coord coord)
        {
            if(!IsInsideBoard(coord)) return null;

            return piecePlacements[coord.rankIndex, coord.fileIndex];
        }

        public bool IsKingInTurn(Coord coord)
        {
            bool result = false;
            Piece selected = GetPiece(coord);
            if (selected != null)
            {
                if(selected.type == King.TYPE && selected.colour == colourToMove)
                {
                    result = true;
                }
            }
            return result;
        }


        void RefreshBuffer()
        {

            for (int i = 0; i < piecePlacements.GetLength(0); i++)
            {
                for (int j = 0; j < piecePlacements.GetLength(1); i++)
                {
                    piecePlacementsBuffered[i, j] = piecePlacements[i, j];
                }
            }

        }

        public void AddSeed(Seed seed,Coord coord)
        {
            seeds.Add(seed);
            PutPiece(seed, coord);
        }

        #region Board modifier functions

        public void PutPiece(Piece piece, Coord coord, bool realBoard=true)
        {
            Piece[,] matrixToChange = realBoard ? piecePlacements : piecePlacementsBuffered;
            if (realBoard)
            {
                lastTakenPiece = piecePlacements[coord.rankIndex, coord.fileIndex]; // buffer the former piece
                if (lastTakenPiece != null)
                {
                    if (lastTakenPiece.type == King.TYPE)
                    {
                        OnKingTaken(lastTakenPiece);
                    }

                    if (lastTakenPiece.type == Seed.TYPE)
                    {
                        seeds.Remove((Seed)lastTakenPiece);
                    }
                }
                piece.position = coord;
            }

            matrixToChange[coord.rankIndex, coord.fileIndex] = piece;
        }

        public void LiftPiece(Coord coord, bool realBoard = true)
        {
            Piece[,] matrixToChange = realBoard ? piecePlacements : piecePlacementsBuffered;
            matrixToChange[coord.rankIndex, coord.fileIndex] = null;
        }
        #endregion

        void OnKingTaken(Piece takenKing)
        {
            OnKingLost?.Invoke(takenKing.colour);
        }
     


        public void MakeMove(Move move)
        {
            Piece piece = GetPiece(move.startCoord);
            LiftPiece(move.startCoord);
            PutPiece(piece, move.targetCoord);
            lastMadeMove = move;
            SetTurn(colourToMove == Piece.COLOR_WHITE ? Piece.COLOR_BLACK : Piece.COLOR_WHITE);
        }

        public void MakePromotionMove(Move move, Piece promotedPiece) // TODO: ayni fonksiyon
        {
          
            LiftPiece(move.startCoord);
            lastMadeMove = move;
            PutPiece(promotedPiece, move.targetCoord);
            SetTurn(colourToMove == Piece.COLOR_WHITE ? Piece.COLOR_BLACK : Piece.COLOR_WHITE);
        }

        public void MakeSeedMove(Move move, Seed createdSeed)
        {
            AddSeed(createdSeed, move.targetCoord);
            SetTurn(colourToMove == Piece.COLOR_WHITE ? Piece.COLOR_BLACK : Piece.COLOR_WHITE);
        }

        public void UnmakeMove()
        {
            Piece lastPlayedPiece = GetPiece(lastMadeMove.targetCoord);
            LiftPiece(lastMadeMove.targetCoord);
            if(lastTakenPiece != null)
            {
                PutPiece(lastTakenPiece, lastMadeMove.targetCoord);
                lastTakenPiece = null;
            }

            if (lastMadeMove.specialCondition == SpecialConditions.PromoteToQueen)
            {
                PutPiece(new Pawn(lastPlayedPiece.colour), lastMadeMove.startCoord);
            }
            else
            {
                PutPiece(lastPlayedPiece, lastMadeMove.startCoord);
            }

            SetTurn(colourToMove == Piece.COLOR_WHITE ? Piece.COLOR_BLACK : Piece.COLOR_WHITE);
        }

        public void GrowSeeds()
        {
            for(int i=seeds.Count-1; i>=0; i--)
            {

                if (seeds[i].colour == colourToMove) continue;

                seeds[i].Grow();
                if (seeds[i].isGrownFull)
                {
                    PutPiece(seeds[i].pieceGrown, seeds[i].position);
                }
            }
        }


        public bool IsInsideBoard(Coord position)
        {
            return position.rankIndex < piecePlacements.GetLength(0)
                && position.fileIndex < piecePlacements.GetLength(1)
            && position.fileIndex >= 0
                && position.rankIndex >= 0;
        }

        public int GetColor(Coord position)
        {
            int result = BLANK;
            if (!IsInsideBoard(position))
            {
                result = OCCUPIED;
            }
            else
            {
                Piece piece = GetPiece(position);
                if (piece != null)
                {
                    result = piece.colour;
                }
            }
            return result;
        }

        public bool IsSeed(Coord position)
        {
            bool result = false;
            Piece piece = GetPiece(position);
            if(piece != null)
            {
                if(piece.type == Seed.TYPE)
                {
                    result = true;
                }
            }
            return result;
        }

        public List<Piece> SelectAllPiecesInColor(int colour)
        {
            List<Piece> result = new List<Piece>();
            for(int i=0; i < piecePlacements.GetLength(0); i++)
            {
                for (int j = 0; j < piecePlacements.GetLength(1); i++)
                {
                    Coord coord = new Coord(i, j);
                    Piece currentPiece = GetPiece(coord);

                    if (currentPiece != null)
                    {
                        if (GetColor(coord) != colour) continue;
                        else result.Add(currentPiece);
                    }
                }
            }
            return result;
        }
    }

}
