using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftwareKingdom.Chess.Core;
using SoftwareKingdom.Chess.UI;
using SoftwareKingdom.Chess.SeedChess;

namespace SoftwareKingdom.Chess.Basic
{
    public class BasicChessGameManager : MonoBehaviour
    {
        const int BASIC_GAME_N_RANKS = 8;
        const int BASIC_GAME_N_FILES = 8;
        // Settings
        public int[] turnsForSeeds;
        // Connections
        public BoardUI boardUI;
        public BoardPool boardPool; // TODO: For only test
        public UIManager uiManager;
        public Player whitePlayer;
        public Player blackPlayer;
        public Player playerToMove;
        public ResultPanel resultPanel;
        Board board;
        // State variables
        // Promotion
        bool waitingForPromotionPieceSelection = false;
        Move waitingPromotionMove;
        bool waitingForSeedPieceSelection = false;
        Move waitingSeedMove;

        void Awake()
        {
            InitConnections();
        }

        void Start()
        {
            InitState();
        }

        void InitConnections()
        {
            uiManager.OnPieceSelected += OnPieceSelected;
        }

        void InitState()
        {
            board = new Board(BASIC_GAME_N_RANKS, BASIC_GAME_N_FILES);
            board.OnKingLost += OnKingLost;

            Piece WK = new King(Piece.COLOR_WHITE);
            Piece BK = new King(Piece.COLOR_BLACK);

            board.PutPiece(WK, new Coord(4, 0));
            board.PutPiece(BK, new Coord(4, 7));
           // boardUI.UpdatePosition(board);

            // Create Human players
            whitePlayer = new HumanPlayer(this.board);
            blackPlayer = new HumanPlayer(this.board);

            whitePlayer.onMoveChosen += OnMoveChosen;
            blackPlayer.onMoveChosen += OnMoveChosen;

            playerToMove = whitePlayer;
        }

        void SwitchTurn()
        {
            playerToMove = playerToMove == whitePlayer ? blackPlayer : whitePlayer;
            board.GrowSeeds();
        }

        void OnMoveChosen(Move move)
        {
            
            if(move.specialCondition == SpecialConditions.PromoteToQueen)
            {
                uiManager.ShowPiecesMenu(board.colourToMove == Piece.COLOR_WHITE, isSeed: false);
                waitingForPromotionPieceSelection = true;
                waitingPromotionMove = move;
            }else if (move.specialCondition == SpecialConditions.DeploySeed)
            {
                uiManager.ShowPiecesMenu(board.colourToMove == Piece.COLOR_WHITE, isSeed: true);
                waitingForSeedPieceSelection = true;
                waitingSeedMove = move;
            }
            else
            {
                board.MakeMove(move); // TODO: Piece will move
                boardUI.DisplayBoardAnimated(board, move.startCoord,move.targetCoord);
                SwitchTurn();
            }



            //searchBoard.MakeMove(move);

            //gameMoves.Add(move);
            //onMoveMade?.Invoke(move);
            //NotifyPlayerToMove();
        }

        void OnUndo()
        {
            board.UnmakeMove(); 
            boardUI.DisplayBoardStatic(board);
            SwitchTurn();
        }

        void OnPieceSelected(int pieceID)
        {
            if (waitingForPromotionPieceSelection)
            {
                OnPromotion(pieceID);
            }
            if (waitingForSeedPieceSelection)
            {
                OnSeed(pieceID);
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pieceID"></param>

        void OnPromotion(int pieceID)
        {
            waitingForPromotionPieceSelection = false;
            int promotionColor = board.GetPiece(waitingPromotionMove.startCoord).colour;
            Piece selectedPiece = CreatePromotionPiece(pieceID, promotionColor);
            board.MakePromotionMove(waitingPromotionMove, selectedPiece);
            boardUI.DisplayBoardAnimated(board, waitingPromotionMove.startCoord, waitingPromotionMove.targetCoord);
            SwitchTurn();
            uiManager.HidePiecesMenu();
        }

        void OnSeed(int pieceID)
        {
            waitingForSeedPieceSelection = false;
            int seedColor = board.GetPiece(waitingSeedMove.startCoord).colour;
            //Piece selectedPiece = CreatePromotionPiece(pieceID, seedColor);
            Seed seed = CreatePromotionSeed(pieceID, seedColor);
            //board.AddSeed(seed, waitingSeedMove.targetCoord);
            board.MakeSeedMove(waitingSeedMove, seed);
            boardUI.DisplayBoardAnimated(board, waitingSeedMove.startCoord, waitingSeedMove.targetCoord);
            
            SwitchTurn();
            uiManager.HidePiecesMenu();
        }
        void OnKingLost(int colour)
        {
            playerToMove = null;
            if(colour == Piece.COLOR_WHITE)
            {
                resultPanel.DisplayResult(1 - colour);
                Debug.Log("Black wins!");
                
            }
            else if (colour == Piece.COLOR_BLACK)
            {
                resultPanel.DisplayResult(1 - colour);
   
            }
            whitePlayer.onMoveChosen -= OnMoveChosen;
            blackPlayer.onMoveChosen -= OnMoveChosen; // TODO: Daha iyi bir detach olma yontemi
        }

        Piece CreatePromotionPiece(int pieceID, int promotionColor)
        {
            Piece promotionPiece = null;
            switch (pieceID)
            {

                case Pawn.TYPE:
                    promotionPiece = new Pawn(promotionColor);
                    break;
                case Knight.TYPE:
                    promotionPiece = new Knight(promotionColor);
                    break;
                case Bishop.TYPE:
                    promotionPiece = new Bishop(promotionColor);
                    break;
                case Rook.TYPE:
                    promotionPiece = new Rook(promotionColor);
                    break;
                case Queen.TYPE:
                    promotionPiece = new Queen(promotionColor);
                    break;

            }

            return promotionPiece;
        }

        Seed CreatePromotionSeed(int pieceID, int promotionColor)
        {
            Piece seedPiece = CreatePromotionPiece(pieceID, promotionColor);
            Seed seed = new Seed(seedPiece, turnsForSeeds[pieceID-1] + 1); // TODO: +1 for inconvenience
            return seed;
        }

        // Update is called once per frame
        void Update()
        {
            playerToMove?.Update();

            if (Input.GetKeyDown(KeyCode.U))
            {
                OnUndo();
            }
        }

        

    }

}

