using SoftwareKingdom.Chess.Core;
using SoftwareKingdom.Chess.RootChess;
using System.Collections;
using System.Collections.Generic;
using System.Xml;
using UnityEngine;
using UnityEngine.UIElements;


namespace SoftwareKingdom.Chess.UI
{
    public class BoardPool : MonoBehaviour
    {

        // Settings
        public Vector3 horizontalOffset;
        public Vector3 verticalOffset;
        public Color lightSquaresColor;
        public Color darkSquaresColor;        
        // Connections
        public Transform startPoint;
        public BoardSquare[] squaresPool;
        Dictionary<Coord, BoardSquare> coordSquareDictionary;
        SquareClickListener squareClickListener;
        PieceLiner pieceLiner;
        // State variables
        int nextSquareIndex;
        void Awake()
        {
            InitConnections();
        }

        void Start()
        {
            InitState();
        }

        void InitConnections()
        {
            coordSquareDictionary = new Dictionary<Coord, BoardSquare>();// TODO: Is this a good approach?
            pieceLiner = GetComponent<PieceLiner>();
        }

        void InitState()
        {
          

        }

        public void CreateBoard(BoardState initialState)
        {
            nextSquareIndex = 0;

            for(int i=0; i < initialState.board.GetLength(0); i++)
            {
                for(int j=0; j < initialState.board.GetLength(1); j++)
                {
                    // You may check initialState[i,j] for some holes
                    Vector3 position = CoordToPosition(i,j);
                    Color squareColor = (i + j) % 2 == 0 ? darkSquaresColor : lightSquaresColor;
                    squaresPool[nextSquareIndex].Configure(i, j, squareColor, position, squareClickListener);
                    Coord coord = new Coord(i, j);  
                    coordSquareDictionary.Add(coord, squaresPool[nextSquareIndex]);

                    // Draw the piece
                    if (!initialState.IsEmpty(i, j)) 
                        pieceLiner.DrawPiece(initialState[coord], squaresPool[nextSquareIndex].pieceNest.position, coord);
                    nextSquareIndex++;
                }
            }
        }

        public void MakeMove(Move move, BoardState boardState)
        {
            Vector3 position = GetPiecePosition(move.targetCoord);
            if( !SeedPlantingMoveGenerator.IsSeedPlantingMove(move))
            {
                pieceLiner.MovePiece(move.startCoord, move.targetCoord, position);
            }
            else
            {
                RootChessBoardState rootChessBoardState = (RootChessBoardState)boardState;
                char pieceLetter = rootChessBoardState.GetSeedPieceNotation(move.targetCoord);
                string pieceNotation = "" +rootChessBoardState.GetTurnPrefix() + pieceLetter; // TODO: Cok dolambacli yol
                int seedTurns = rootChessBoardState.GetSeedPieceGrowTurns(move.targetCoord);
                pieceLiner.AddSeed(pieceNotation.ToString(),  position, move.targetCoord, seedTurns);
                Debug.Log("Grow seed: " + move.specialCondition + " at " + move.targetCoord);
            }
        }

        public void UpdateSeeds(BoardState boardState)
        {
            RootChessBoardState rootChessBoardState = (RootChessBoardState)boardState;

            for(int i=0; i< boardState.board.GetLength(0); i++)
            {
                for (int j = 0; j < boardState.board.GetLength(1); j++)
                {

                    //char pieceLetter = rootChessBoardState.GetSeedPieceNotation(move.targetCoord);
                }
            }

            //string pieceNotation = "" + rootChessBoardState.GetTurnPrefix() + pieceLetter; // TODO: Cok dolambacli yol
            //int seedTurns = rootChessBoardState.GetSeedPieceGrowTurns(move.targetCoord);
            //pieceLiner.AddSeed(pieceNotation.ToString(), position, move.targetCoord, seedTurns);
            //Debug.Log("Grow seed: " + move.specialCondition + " at " + move.targetCoord);
        }



        public void Highlight(int rankIndex, int fileIndex)
        {
            BoardSquare square = coordSquareDictionary[new Coord(rankIndex, fileIndex)];
            square.Highlight();
        }

        public void HighlightMoves(List<Move> moves)
        {
            for(int i=0; i<moves.Count; i++)
            {
                Highlight(moves[i].targetCoord.rankIndex, moves[i].targetCoord.fileIndex);
            }
        }

        public void UnHighlight()
        {

            foreach (KeyValuePair<Coord, BoardSquare> entry in coordSquareDictionary)
            {
                entry.Value.UnHighlight();
            }
        }



        public void SetSquareClickListener(SquareClickListener squareClickListener)
        {
            this.squareClickListener = squareClickListener;
        }

        #region Appendix Functions

        private Vector3 CoordToPosition(int i, int j)
        {
            return startPoint.position + (i * verticalOffset) + (j * horizontalOffset); 
        }

        private Vector3 GetPiecePosition(Coord coord)
        {
            BoardSquare square = coordSquareDictionary[coord];
            return square.pieceNest.position;
        }

        #endregion

        // Update is called once per frame
        void Update()
        {

        }
    }

}

