using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using SoftwareKingdom.Chess.SeedChess;

public class SproutRenderer : MonoBehaviour
{
    const int maxTurnToGrow = 10;
    const float minPieceSizeFactor = 0.5f;
    const float maxPieceSizeFactor = 1.0f;
    // Settings

    // Connections
    public TextMeshPro arrivalTimeText;
    public SpriteRenderer figureSprite;
    // State variables
    Vector3 figureSpriteInitialScale;

    void Awake(){
        InitConnections();
    }

    void Start()
    {
        InitState();
    }

    void InitConnections(){
    }

    void InitState(){
        figureSpriteInitialScale = figureSprite.transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void DrawSeed(Seed seed, Sprite pieceSprite)
    {
        gameObject.SetActive(true);
        arrivalTimeText.text = seed.GetRemainingTurnTime().ToString();
        figureSprite.sprite = pieceSprite;
        float arrivalProgress = (float)seed.currentLevel / (float)seed.levelToSprout;
    }

    


    
}
