using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine.UI;

using SoftwareKingdom.Chess.Core;

public class PieceSelectionButton : MonoBehaviour
{

    // Settings

    // Connections
    public Image targetImage;
    public Sprite whiteSprite;
    public Sprite blackSprite;
    // State variables

    void Awake(){
        InitConnections();
    }

    void Start()
    {
        InitState();
    }

    void InitConnections(){
       
    }

    void InitState(){
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SelectVariant(int pieceColor)
    {
        Sprite targetImageSprite = pieceColor == Piece.COLOR_WHITE ? whiteSprite : blackSprite;

        targetImage.sprite = targetImageSprite;

    }

}
