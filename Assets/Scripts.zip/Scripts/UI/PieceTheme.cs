﻿using UnityEngine;
using SoftwareKingdom.Chess.Core;
namespace SoftwareKingdom.Chess.UI
{
	[CreateAssetMenu (menuName = "Theme/Pieces")]
	public class PieceTheme : ScriptableObject {

		public PieceSprites whitePieces;
		public PieceSprites blackPieces;
		public Sprite whiteSprout;
        public Sprite blackSprout;

        public Sprite GetPieceSprite (Piece piece) {
            if (piece == null) return null;
            PieceSprites pieceSprites = piece.colour  == Piece.COLOR_WHITE ? whitePieces : blackPieces;
			switch (piece.type) {
				case Bishop.TYPE:
					return pieceSprites.bishop;
				case Rook.TYPE:
					return pieceSprites.rook;
				case Queen.TYPE:
					return pieceSprites.queen;
				case Knight.TYPE:
					return pieceSprites.knight;
				case Pawn.TYPE:
					return pieceSprites.pawn;
				case King.TYPE:
					return pieceSprites.king;
				case SeedChess.Seed.TYPE:
					return piece.colour == Piece.COLOR_WHITE ? whiteSprout : blackSprout;
				default:
					if (piece.type != 0) {
						Debug.Log (piece);
					}
					return null;
			}
		}

        


        [System.Serializable]
		public class PieceSprites {
			public Sprite pawn, rook, knight, bishop, queen, king;

			public Sprite this [int i] {
				get {
					return new Sprite[] { pawn, rook, knight, bishop, queen, king }[i];
				}
			}
		}
	}
}