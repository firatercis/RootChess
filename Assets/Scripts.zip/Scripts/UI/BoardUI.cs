﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using SoftwareKingdom.Chess.Core;

using SoftwareKingdom.Chess.SeedChess;
using System;

namespace SoftwareKingdom.Chess.UI {
	public class BoardUI : MonoBehaviour {
        const float pieceDepth = -0.1f;
		const float pieceDragDepth = -0.2f;

		// Settings
		public bool showLegalMoves;
		public bool whiteIsBottom = true;
		public PieceTheme pieceTheme;
		public PieceSet pieceSet;
		public BoardTheme boardTheme;
		public Sprite whiteSeed;
		public Sprite blackSeed;
		public GameObject seedPrefab;


		// Connections
		MeshRenderer[, ] squareRenderers;
		SpriteRenderer[, ] squarePieceRenderers;
		public event Action OnSquareSelected;
		
		//Move lastMadeMove;
		//MoveGenerator moveGenerator;

		Coord lastStartCoord;
		Coord lastTargetCoord;

		void Awake () {
			//moveGenerator = new MoveGenerator ();
			CreateBoardUI ();

		}

		public void HighlightLegalMoves (Board board, Coord fromSquare) {
			if (showLegalMoves)
			{

				Piece selectedPiece = board.GetPiece (fromSquare);
				List<Move> moves = selectedPiece.GenerateMoves(board);

				for (int i = 0; i < moves.Count; i++)
				{
					Move move = moves[i];

					Coord coord = move.targetCoord;
					SetSquareColour(coord, boardTheme.lightSquares.legal, boardTheme.darkSquares.legal);
					
				}
			}
		}

		public void HighlightSqares(Move[] moves)
		{

		}

		public void DragPiece (Coord pieceCoord, Vector2 mousePos) {
		//	squarePieceRenderers[pieceCoord.fileIndex, pieceCoord.rankIndex].transform.position = new Vector3 (mousePos.x, mousePos.y, pieceDragDepth);
		}

		public void ResetPiecePosition (Coord pieceCoord) {
			Vector3 pos = PositionFromCoord (pieceCoord.fileIndex, pieceCoord.rankIndex, pieceDepth);
			squarePieceRenderers[pieceCoord.fileIndex, pieceCoord.rankIndex].transform.position = pos;
		}

		public void SelectSquare (Coord coord) {
			SetSquareColour (coord, boardTheme.lightSquares.selected, boardTheme.darkSquares.selected);
		}

		public void DeselectSquare (Coord coord) {
			//BoardTheme.SquareColours colours = (coord.IsLightSquare ()) ? boardTheme.lightSquares : boardTheme.darkSquares;
			//squareMaterials[coord.file, coord.rank].color = colours.normal;
			ResetSquareColours ();
		}

		public bool TryGetSquareUnderMouse (Vector2 mouseWorld, out Coord selectedCoord) {
			int file = (int) (mouseWorld.x + 4);
			int rank = (int) (mouseWorld.y + 4);
			if (!whiteIsBottom) {
				file = 7 - file;
				rank = 7 - rank;
			}
			selectedCoord = new Coord (file, rank);
			return file >= 0 && file < 8 && rank >= 0 && rank < 8;
		}

		public void UpdatePosition (Board board) {
			for (int rank = 0; rank < board.piecePlacements.GetLength(0); rank++) {
				for (int file = 0; file < board.piecePlacements.GetLength(1); file++) {
					Coord coord = new Coord (file, rank);
					Piece piece = board.GetPiece(coord);
					
					DrawPiece(squarePieceRenderers[file, rank], piece, file, rank);
                    //squarePieceRenderers[file, rank].sprite = pieceTheme.GetPieceSprite(piece);
                    //squarePieceRenderers[file, rank].transform.position = PositionFromCoord(file, rank, pieceDepth);
				}
			}
		}

		public void UpdatePosition(BoardState boardState)
		{
            for (int rank = 0; rank < boardState.board.GetLength(0); rank++)
            {
                for (int file = 0; file < boardState.board.GetLength(1); file++)
                {

					string piece = boardState[file,rank];
					if(piece != BoardState.EMPTY_SQUARE)
						DrawPiece(squarePieceRenderers[file, rank], piece, file, rank);
                }
            }
        }


        public void DrawPiece(SpriteRenderer target, string piece, int file, int rank)
        {
            //SproutRenderer sproutRenderer = target.GetComponentInChildren<SproutRenderer>(includeInactive: true);
            //sproutRenderer.gameObject.SetActive(false);
			target.sprite = pieceSet.GetPieceSprite(piece);
			target.transform.position = PositionFromCoord(file, rank, pieceDepth);
        }

        public void DrawPiece(SpriteRenderer target, Piece piece, int file, int rank)
		{
            SproutRenderer sproutRenderer = target.GetComponentInChildren<SproutRenderer>(includeInactive:true);
			sproutRenderer.gameObject.SetActive(false);
			if (piece == null)
			{
				target.sprite = null; return;
			}
            if (piece.type != Seed.TYPE)
			{
				target.sprite = pieceTheme.GetPieceSprite(piece);
				target.transform.position = PositionFromCoord(file, rank, pieceDepth);
                
            }
			else
			{
				Seed seedPiece = (Seed)piece;
				Sprite pieceSprite = pieceTheme.GetPieceSprite(seedPiece.pieceGrown);
				sproutRenderer.DrawSeed(seedPiece, pieceSprite);
            }
        }

		public void DisplayBoardAnimated(Board board, Coord startCoord, Coord targetCoord)
		{
			lastStartCoord = startCoord;
			lastTargetCoord = targetCoord;
            StartCoroutine(AnimateMove(startCoord, targetCoord,board));
        }

		public void DisplayBoardStatic (Board board ) {
            UpdatePosition(board);
            ResetSquareColours();
            //	lastMadeMove = move;
          
		}

		IEnumerator AnimateMove (Coord startCoord, Coord targetCoord, Board board) {
			float t = 0;
			const float moveAnimDuration = 0.15f;
	
			Transform pieceT = squarePieceRenderers[startCoord.fileIndex, startCoord.rankIndex].transform;
			Vector3 startPos = PositionFromCoord (startCoord);
			Vector3 targetPos = PositionFromCoord (targetCoord);
			SetSquareColour (startCoord, boardTheme.lightSquares.moveFromHighlight, boardTheme.darkSquares.moveFromHighlight);

			while (t <= 1) {
				yield return null;
				t += Time.deltaTime * 1 / moveAnimDuration;
				pieceT.position = Vector3.Lerp (startPos, targetPos, t);
			}
			UpdatePosition (board);
			ResetSquareColours ();
			pieceT.position = startPos;
		}

		//void HighlightMove (Move move) {
		//	SetSquareColour (BoardRepresentation.CoordFromIndex (move.StartSquare), boardTheme.lightSquares.moveFromHighlight, boardTheme.darkSquares.moveFromHighlight);
		//	SetSquareColour (BoardRepresentation.CoordFromIndex (move.TargetSquare), boardTheme.lightSquares.moveToHighlight, boardTheme.darkSquares.moveToHighlight);
		//}

		void CreateBoardUI () {
			pieceSet.Load();

			Shader squareShader = Shader.Find ("Unlit/Color");
			squareRenderers = new MeshRenderer[8, 8];
			squarePieceRenderers = new SpriteRenderer[8, 8];

			for (int rank = 0; rank < 8; rank++) {
				for (int file = 0; file < 8; file++) {
					// Create square
					Transform square = GameObject.CreatePrimitive (PrimitiveType.Quad).transform;
					square.parent = transform;
					//	square.name = BoardRepresentation.SquareNameFromCoordinate (file, rank);
					square.name = "";
					square.position = PositionFromCoord (file, rank, 0);
					Material squareMaterial = new Material (squareShader);

					squareRenderers[file, rank] = square.gameObject.GetComponent<MeshRenderer> ();
					squareRenderers[file, rank].material = squareMaterial;

					// Create piece sprite renderer for current square
					SpriteRenderer pieceRenderer = new GameObject ("Piece").AddComponent<SpriteRenderer> ();
					pieceRenderer.transform.parent = square;
					pieceRenderer.transform.position = PositionFromCoord (file, rank, pieceDepth);
					pieceRenderer.transform.localScale = Vector3.one * 100 / (2000 / 6f);
					squarePieceRenderers[file, rank] = pieceRenderer;
					GameObject seedGO = Instantiate(seedPrefab, pieceRenderer.transform);
					seedGO.SetActive(false);

				}
			}

			ResetSquareColours ();
		}

		void CreateSquareUI()
		{

		}


		void ResetSquarePositions () {
			for (int rank = 0; rank < 8; rank++) {
				for (int file = 0; file < 8; file++) {
					if (file == 0 && rank == 0) {
						//Debug.Log (squarePieceRenderers[file, rank].gameObject.name + "  " + PositionFromCoord (file, rank, pieceDepth));
					}
					//squarePieceRenderers[file, rank].transform.position = PositionFromCoord (file, rank, pieceDepth);
					squareRenderers[file, rank].transform.position = PositionFromCoord (file, rank, 0);
					squarePieceRenderers[file, rank].transform.position = PositionFromCoord (file, rank, pieceDepth);
				}
			}

			//if (!lastMadeMove.IsInvalid) {
			//	HighlightMove (lastMadeMove);
			//}
		}

		public void SetPerspective (bool whitePOV) {
			whiteIsBottom = whitePOV;
			ResetSquarePositions ();

		}

		public void ResetSquareColours (bool highlight = true) {
			for (int rank = 0; rank < 8; rank++) {
				for (int file = 0; file < 8; file++) {
					SetSquareColour (new Coord (file, rank), boardTheme.lightSquares.normal, boardTheme.darkSquares.normal);
				}
			}
			if (highlight) {
				//if (!lastMadeMove.IsInvalid) {
				//	HighlightMove (lastMadeMove);
				//}
			}
		}

		void SetSquareColour (Coord square, Color lightCol, Color darkCol) {
			squareRenderers[square.fileIndex, square.rankIndex].material.color = (square.IsLightSquare ()) ? lightCol : darkCol;
		}

		public Vector3 PositionFromCoord (int file, int rank, float depth = 0) {
			if (whiteIsBottom) {
				return new Vector3 (-3.5f + file, -3.5f + rank, depth);
			}
			return new Vector3 (-3.5f + 7 - file, 7 - rank - 3.5f, depth);

		}

		public Vector3 PositionFromCoord (Coord coord, float depth = 0) {
			return PositionFromCoord (coord.fileIndex, coord.rankIndex, depth);
		}

	}
}