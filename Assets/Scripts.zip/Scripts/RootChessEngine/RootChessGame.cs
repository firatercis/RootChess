using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SoftwareKingdom.Chess.Core;
using System.Linq;

namespace SoftwareKingdom.Chess.RootChess
{
    public class RootChessGame : ChessGame
    {
        static char[] seedLetters =  StandardChessGame.pieceLetters.Concat(new char[] { 'T', 'L' }).ToArray();


        public int[] growTurns =
        {
            1, // PAWN
            3, // KNIGHT
            3, // BISHOP
            5, // ROOK
            9, // QUEEN
            40, // KING
            3, // TIMER
            3, // PLANT
        };

        static string[,] initialRootChessBoard =
       {
            { null, null,null, null, "WK", null,null,null  },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null,null,null,null,null,null,null,null },
            { null, null,null,null,null,null,null ,null },
            { null, null,null, null, "BK", null,null,null },
        };

        // Settings
    
        // Connections

        // State variables

        public RootChessGame(List<string> flags = null) : base(CreateRootChessInitialState(flags), CreateRootChessMoveGenerator()) // TODO: Seed variants
        {
        }

        private static BoardState CreateRootChessInitialState(List<string> flags)
        {

            RootChessBoardState initialBoardState = new RootChessBoardState(initialRootChessBoard, flags);
            return initialBoardState;
        }

        private static MoveGenerator CreateRootChessMoveGenerator()
        {

            MoveGenerator rootChessMoveGenerator = new RootChessMoveGenerator(
                StandardChessGame. pieceLetters,
                 StandardChessGame.CreateStandardPieceMoveGenerators()
            ); // Inputs Same as standard chess
            return rootChessMoveGenerator;
        }


        public virtual List<Move> GetPossibleSeedMoves(int seedDeployID) // KN: TODO: Selected seed
        {

            RootChessMoveGenerator rootChessMoveGenerator = (RootChessMoveGenerator) moveGenerator;

            return rootChessMoveGenerator.GenerateSeedMoves(
                (RootChessBoardState)boardState,
                seedDeployID
                ).ToList();
           // return moveGenerator.GeneratePieceMoves(boardState, sourceCoord);
        }

        public override void PlayMove(Move move)
        {
            GrowSeeds();
            if (SeedPlantingMoveGenerator.IsSeedPlantingMove(move))
            {
                PlayPlantingMove(move);
            }
            else
            {
                base.PlayMove(move);
            }
        }

        private void PlayPlantingMove(Move move)
        {
            Debug.Log("Seed movement");
            int seedIndex = move.specialCondition - SeedPlantingMoveGenerator.MOVE_DEPLOY_PAWN_SEED;
            string seedNotation = boardState.GetTurnPrefix() + "S" + seedLetters[seedIndex] + growTurns[seedIndex];// Ex. WSB3 , White seed for bishop to grow in 3 turns
            boardState[move.targetCoord] = seedNotation;
            OnMovePlayed?.Invoke(move);
        }

        void GrowSeeds()
        {
            for(int i=0; i< boardState.board.GetLength(0); i++)
            {
                for (int j = 0; j < boardState.board.GetLength(1); j++)
                {
                    Coord currentCoord = new Coord(i, j);

                    if(boardState.GetPieceNotation(currentCoord) == RootChessBoardState.SEED_NOTATION)
                    {
                        string grownSeed = GrowSeedPiece(boardState[currentCoord]);
                        boardState[currentCoord] = grownSeed;
                    }   
                }
            }
        }

        string GrowSeedPiece(string inPiece)
        {
            RootChessBoardState rootChessBoardState = (RootChessBoardState)boardState;
            int growTurns = rootChessBoardState.GetSeedPieceGrowTurns(inPiece);
            growTurns--;
            string output = "";
            if (growTurns > 0)
            {
                string piecePrefixWithoutNumber = rootChessBoardState.GetSeedPieceWithoutTurns(inPiece);
                output = piecePrefixWithoutNumber + growTurns;
            }
            else
            {
                output = rootChessBoardState.GetFullyGrownPiece(inPiece);

            }
            return output;

        }

    }

}

