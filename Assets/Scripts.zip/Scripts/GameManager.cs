using SoftwareKingdom.Chess.Core;
using SoftwareKingdom.Chess.RootChess;
using SoftwareKingdom.Chess.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameManager : MonoBehaviour
{

    // Settings

    // Connections
    public BoardPool boardPool;
    public SeedSelectionPanel seedSelectionPanel;
    public HumanPlayerControl humanPlayer;
    ChessGame game;
    // State variables
    BoardState currentBoardState;
    void Awake(){
        InitConnections();
    }

    void Start()
    {
        InitState();
    }

    void InitConnections(){

    }

    void InitState(){

        game = new RootChessGame(); // TODO: Create game diye bir yere alinabilir.
        game.OnMovePlayed += OnMovePlayed;
        humanPlayer.game = game;
        humanPlayer.WaitTurn();
        boardPool.CreateBoard(game.boardState); // TODO: For only test
        seedSelectionPanel.SetSeedsDisplay(new string[] { "P", "N", "B", "R", "Q" }); // TODO: Get Available seeds 
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnMoveSelected(Move move)
    {

    }

    public void OnMovePlayed(Move move)
    {
        boardPool.MakeMove(move, game.boardState);
    }
   
}
