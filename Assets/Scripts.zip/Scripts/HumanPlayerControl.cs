using SoftwareKingdom.Chess.Core;
using SoftwareKingdom.Chess.RootChess;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;


namespace SoftwareKingdom.Chess.UI
{
    public class HumanPlayerControl : MonoBehaviour, SquareClickListener, SeedSelectionPanelListener
    {

        // Settings

        // Connections
        public BoardPool boardPool;
        public SeedSelectionPanel seedSelectionPanel;
        public ChessGame game;
        // State variables
        bool pieceSelected;
        bool seedSelected;
        List<Move> selectedPossibleMoves;
        bool waitingForTurn;
        void Awake()
        {
            InitConnections();
        }

        void Start()
        {
            InitState();
        }

        void InitConnections()
        {
            boardPool.SetSquareClickListener(this);
            seedSelectionPanel.SetListener(this);
        }

        void InitState()
        {
            pieceSelected = false;
        }

        // Update is called once per frame
        void Update()
        {

        }

        public void Configure(StandardChessGame game, BoardPool boardPool)
        {
            this.boardPool = boardPool;
            this.game = game;
        }

        public void OnSquareClick(int rankIndex, int fileIndex)
        {
            if (!waitingForTurn) return; // If it is not your turn, do nothing

            if (!pieceSelected)
            {
                boardPool.UnHighlight();
                selectedPossibleMoves = game.GetPossibleMoves(new Coord(rankIndex, fileIndex));
                if (selectedPossibleMoves.Count > 0)
                {
                    boardPool.HighlightMoves(selectedPossibleMoves);
                    pieceSelected = true;
                    // TODO: Piece selected effect
                }
            }
            else
            {
                Move[] selectedMoves = selectedPossibleMoves.Where(x => x.targetCoord.fileIndex == fileIndex && x.targetCoord.rankIndex == rankIndex).ToArray();
                if (selectedMoves.Length > 0)
                {
                    game.PlayMove(selectedMoves[0]);
                }
                boardPool.UnHighlight();
                pieceSelected = false;
            }
        }

        public void WaitTurn()
        {
            waitingForTurn = true;
        }

        public void OnSeedSelected(int seedIndex)
        {

            boardPool.UnHighlight();
            if (pieceSelected)
            {
                pieceSelected= false;  
            }

            RootChessGame rootChessGame = (RootChessGame)game;
                       
            selectedPossibleMoves = rootChessGame.GetPossibleSeedMoves(seedIndex);
            if (selectedPossibleMoves.Count > 0)
            {
                boardPool.HighlightMoves(selectedPossibleMoves);
                pieceSelected = true;
                // TODO: Piece selected effect
            }
            
            
        }
    }
}


